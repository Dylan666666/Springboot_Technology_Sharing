package com.oym.yimianrujiu.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: Mr_OO
 * @Date: 2020/10/2 11:09
 */
@RestController
public class FirstController {

    @GetMapping("/first")
    public Object first() {
        return "first controller";
    }

    @GetMapping("/doError")
    public Object error() {
        return 1 / 0;
    }
    
}
