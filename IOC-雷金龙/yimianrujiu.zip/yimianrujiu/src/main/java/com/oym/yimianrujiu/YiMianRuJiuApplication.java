package com.oym.yimianrujiu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author: Mr_OO
 * @Date: 2020/6/25 20:08
 */
@SpringBootApplication
public class YiMianRuJiuApplication {

    public static void main(String[] args) {
        SpringApplication.run(YiMianRuJiuApplication.class, args);
    }

}
