package com.oym.yimianrujiu.dao;

/**
 * Hr或专家基本信息类
 * @Author: Mr_OO
 * @Date: 2020/7/1 15:53
 */
public interface HrInfoDao {
}
