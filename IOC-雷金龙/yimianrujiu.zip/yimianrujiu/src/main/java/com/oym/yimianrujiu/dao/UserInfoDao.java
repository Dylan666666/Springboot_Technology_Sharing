package com.oym.yimianrujiu.dao;


import com.oym.yimianrujiu.entity.School;
import com.oym.yimianrujiu.entity.UserInfo;

import java.util.List;

/**
 * 用户信息类
 * @Author: Mr_OO
 * @Date: 2020/6/30 20:28
 */
public interface UserInfoDao {

    /**
     * 通过用户Id查询用户基础信息
     *
     * @param webUserId
     * @return
     */
    UserInfo queryUserInfoById(Long webUserId);

    /**
     * 添加用户信息
     * 
     * @param userInfo
     * @return
     */
    int insertUserInfo(UserInfo userInfo);

    /**
     * 修改用户信息
     * 
     * @param userInfo
     * @return
     */
    int updateUserInfo(UserInfo userInfo);

    /**
     * 删除用户信息
     * @param webUserId
     * @return
     */
    int deleteUserInfo(Long webUserId);

    /**
     * 得到所有school信息
     * @return
     */
    List<School> querySchool();

    /**
     * 查询该院校名称
     * 
     * @param schoolId
     * @return
     */
    String querySchoolById(Long schoolId);
    
}
