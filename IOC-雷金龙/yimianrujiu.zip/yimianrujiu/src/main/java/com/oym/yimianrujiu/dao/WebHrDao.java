package com.oym.yimianrujiu.dao;

import com.oym.yimianrujiu.entity.WebHr;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/1 15:15
 */
public interface WebHrDao {
    /**
     * 根据查询条件分页返回账户信息列表
     * 
     * @param webHrCondition
     * @param rowIndex
     * @param pageSize
     * @return
     */
    List<WebHr> queryWebHrList(@Param("webHrCondition") WebHr webHrCondition,
                                   @Param("rowIndex")int rowIndex,
                                   @Param("pageSize")int pageSize);

    /**
     * 根据查询条件返回总数，配合queryPersonInfoList使用
     * 
     * @param webHrrCondition
     * @return
     */
    int queryWebHrCount(WebHr webHrrCondition);

    /**
     * 通过用户Id查询用户
     * 
     * @param webHrId
     * @return
     */
    WebHr queryWebHrById(Long webHrId);

    /**
     * 通过用户Id查询用户
     * 
     * @param phone
     * @return
     */
    WebHr queryWebHrByPhone(Long phone);

    /**
     * 通过帐号和密码查询对应信息，登录用
     * 
     * @param webHrId
     * @param password
     * @return
     */
    WebHr queryWebHrIdAndPwd(@Param("webHrId") Long webHrId,
                             @Param("password") String password);

    /**
     * 添加用户信息
     * 
     * @param webHr
     * @return
     */
    int insertWebHr(WebHr webHr);

    /**
     * 修改用户信息
     * 
     * @param webHr
     * @return
     */
    int updateWebHr(WebHr webHr);

    /**
     * 通过 webHrId,password更改密码
     *
     * @param webUserId
     * @param password
     * @param newPassword
     * @param lastEditTime
     * @return
     */
    int updateWebHrById(@Param("webUserId") Long webUserId,
                          @Param("password") String password,
                          @Param("newPassword") String newPassword,
                          @Param("lastEditTime") Date lastEditTime);

    /**
     * 通过 phone,password更改密码
     *
     * @param phone
     * @param password
     * @param newPassword
     * @param lastEditTime
     * @return
     */
    int updateWebHrByPhone(@Param("phone") Long phone,
                             @Param("password") String password,
                             @Param("newPassword") String newPassword,
                             @Param("lastEditTime") Date lastEditTime);

}
