package com.oym.yimianrujiu.dao;

import com.oym.yimianrujiu.entity.WebUser;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * 用户账户类
 * @Author: Mr_OO
 * @Date: 2020/7/1 14:16
 */
public interface WebUserDao {

    /**
     * 根据查询条件分页返回账户信息列表
     * 
     * @param webUserCondition
     * @param rowIndex
     * @param pageSize
     * @return
     */
    List<WebUser> queryWebUserList(@Param("webUserCondition") WebUser webUserCondition,
                                   @Param("rowIndex")int rowIndex,
                                   @Param("pageSize")int pageSize);

    /**
     * 根据查询条件返回总数，配合queryPersonInfoList使用
     * 
     * @param webUserCondition
     * @return
     */
    int queryWebUserCount(@Param("webUserCondition")WebUser webUserCondition);

    /**
     * 通过用户Id查询用户
     * 
     * @param webUserId
     * @return
     */
    WebUser queryWebUserById(Long webUserId);

    /**
     * 通过用户电话号码查询用户
     * 
     * @param phone
     * @return
     */
    WebUser queryWebUserByPhone(Long phone);

    /**
     * 通过帐号和密码查询对应信息，登录用
     * @param webUserId
     * @param password
     * @return
     */
    WebUser queryWebUserByIdAndPwd(@Param("webUserId") Long webUserId,
                                 @Param("password") String password);

    /**
     * 通过手机号和密码查询对应信息，登录用
     * 
     * @param phone
     * @param password
     * @return
     */
    WebUser queryWebUserByPhoneAndPwd(@Param("phone") Long phone,
                                   @Param("password") String password);

    /**
     * 注册用户信息
     * 
     * @param webUser
     * @return
     */
    int insertWebUser(WebUser webUser);

    /**
     * 通过刚注册的信息查询用户ID
     * 
     * @param phone
     * @return
     */
    Long getWebUserId(Long phone);
    
    /**
     * 修改用户信息
     * 
     * @param webUser
     * @return
     */
    int updateWebUser(WebUser webUser);

    /**
     * 注销用户
     * 
     * @param webUserId
     * @return
     */
    int deleteWebUser(Long webUserId);

    /**
     * 通过 webUserId,password更改密码
     * 
     * @param webUserId
     * @param newPassword
     * @param lastEditTime
     * @return
     */
    int updatePasswordById(@Param("webUserId") Long webUserId,
                      @Param("newPassword") String newPassword,
                      @Param("lastEditTime") Date lastEditTime);

    /**
     * 通过 phone,password更改密码
     * 
     * @param phone
     * @param newPassword
     * @param lastEditTime
     * @return
     */
    int updatePasswordByPhone(@Param("phone") Long phone,
                      @Param("newPassword") String newPassword,
                      @Param("lastEditTime") Date lastEditTime);
    
}
