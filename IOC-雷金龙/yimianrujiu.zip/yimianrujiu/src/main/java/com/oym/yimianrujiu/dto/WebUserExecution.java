package com.oym.yimianrujiu.dto;

import com.oym.yimianrujiu.entity.WebUser;
import com.oym.yimianrujiu.enums.WebUserStateEnum;

import java.util.List;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:57
 */
public class WebUserExecution {
    private int state;
    private int count;
    private String stateInfo;
    private WebUser webUser;
    private List<WebUser> webUserList;

    public WebUserExecution(WebUserStateEnum webUserStateEnum) {
        this.state = webUserStateEnum.getState();
        this.stateInfo = webUserStateEnum.getStateInfo();
    }

    public WebUserExecution(WebUserStateEnum webUserStateEnum, WebUser webUser) {
        this.state = webUserStateEnum.getState();
        this.stateInfo = webUserStateEnum.getStateInfo();
        this.webUser = webUser;
    }


    public WebUserExecution(WebUserStateEnum webUserStateEnum, List<WebUser> webUserList) {
        this.webUserList = webUserList;
        this.state = webUserStateEnum.getState();
        this.stateInfo = webUserStateEnum.getStateInfo();
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getStateInfo() {
        return stateInfo;
    }

    public void setStateInfo(String stateInfo) {
        this.stateInfo = stateInfo;
    }

    public WebUser getWebUser() {
        return webUser;
    }

    public void setWebUser(WebUser webUser) {
        this.webUser = webUser;
    }

    public List<WebUser> getWebUserList() {
        return webUserList;
    }

    public void setWebUserList(List<WebUser> webUserList) {
        this.webUserList = webUserList;
    }
}
