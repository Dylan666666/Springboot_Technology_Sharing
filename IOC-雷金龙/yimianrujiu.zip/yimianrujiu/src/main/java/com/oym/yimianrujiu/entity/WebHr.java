package com.oym.yimianrujiu.entity;

import java.util.Date;

/**
 * hr或者专家账户信息
 * @Author: Mr_OO
 * @Date: 2020/6/30 16:13
 */
public class WebHr {
    private Long webHrId;
    private String name;
    private String profileImg;
    private String personalProfile;
    private String signature;
    private String password;
    private Integer enableStatus;
    private Long account;
    private Long signPoint;
    private Long interviewNumber;
    private Long highNumber;
    private Long badNumber;
    private Long reservationNumber;
    private Long questionsAnswerNumber;
    private Date createTime;
    private Date lastEditTime;
    
    private HrInfo hrInfo;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImg() {
        return profileImg;
    }

    public void setProfileImg(String profileImg) {
        this.profileImg = profileImg;
    }

    public String getPersonalProfile() {
        return personalProfile;
    }

    public void setPersonalProfile(String personalProfile) {
        this.personalProfile = personalProfile;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Integer getEnableStatus() {
        return enableStatus;
    }

    public void setEnableStatus(Integer enableStatus) {
        this.enableStatus = enableStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastEditTime() {
        return lastEditTime;
    }

    public void setLastEditTime(Date lastEditTime) {
        this.lastEditTime = lastEditTime;
    }

    public HrInfo getHrInfo() {
        return hrInfo;
    }

    public void setHrInfo(HrInfo hrInfo) {
        this.hrInfo = hrInfo;
    }

    public Long getWebHrId() {
        return webHrId;
    }

    public void setWebHrId(Long webHrId) {
        this.webHrId = webHrId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getAccount() {
        return account;
    }

    public void setAccount(Long account) {
        this.account = account;
    }

    public Long getSignPoint() {
        return signPoint;
    }

    public void setSignPoint(Long signPoint) {
        this.signPoint = signPoint;
    }

    public Long getInterviewNumber() {
        return interviewNumber;
    }

    public void setInterviewNumber(Long interviewNumber) {
        this.interviewNumber = interviewNumber;
    }

    public Long getHighNumber() {
        return highNumber;
    }

    public void setHighNumber(Long highNumber) {
        this.highNumber = highNumber;
    }

    public Long getBadNumber() {
        return badNumber;
    }

    public void setBadNumber(Long badNumber) {
        this.badNumber = badNumber;
    }

    public Long getReservationNumber() {
        return reservationNumber;
    }

    public void setReservationNumber(Long reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public Long getQuestionsAnswerNumber() {
        return questionsAnswerNumber;
    }

    public void setQuestionsAnswerNumber(Long questionsAnswerNumber) {
        this.questionsAnswerNumber = questionsAnswerNumber;
    }
}
