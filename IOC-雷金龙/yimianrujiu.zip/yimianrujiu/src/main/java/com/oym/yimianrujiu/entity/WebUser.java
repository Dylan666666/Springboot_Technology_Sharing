package com.oym.yimianrujiu.entity;

import com.oym.yimianrujiu.dao.WebUserDao;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * 普通账户
 * @Author: Mr_OO
 * @Date: 2020/6/30 16:13
 */
public class WebUser {
    private Long webUserId;
    private String name;
    private String profileImg;
    private String intentionOccupation;
    private String signature;
    private String password;
    private Integer enableStatus;
    private Long phone;
    private Long account;
    private Long signPoint;
    private Date createTime;
    private Date lastEditTime;
    
    public Long getPhone() {
        return phone;
    }

    public void setPhone(Long phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImg() {
        return profileImg;
    }

    public void setProfileImg(String profileImg) {
        this.profileImg = profileImg;
    }

    public String getIntentionOccupation() {
        return intentionOccupation;
    }

    public void setIntentionOccupation(String intentionOccupation) {
        this.intentionOccupation = intentionOccupation;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
    
    public Integer getEnableStatus() {
        return enableStatus;
    }

    public void setEnableStatus(Integer enableStatus) {
        this.enableStatus = enableStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastEditTime() {
        return lastEditTime;
    }

    public void setLastEditTime(Date lastEditTime) {
        this.lastEditTime = lastEditTime;
    }
    
    public Long getWebUserId() {
        return webUserId;
    }

    public void setWebUserId(Long webUserId) {
        this.webUserId = webUserId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getAccount() {
        return account;
    }

    public void setAccount(Long account) {
        this.account = account;
    }

    public Long getSignPoint() {
        return signPoint;
    }

    public void setSignPoint(Long signPoint) {
        this.signPoint = signPoint;
    }
}
