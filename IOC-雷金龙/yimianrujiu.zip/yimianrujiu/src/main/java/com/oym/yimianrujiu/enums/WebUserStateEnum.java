package com.oym.yimianrujiu.enums;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:31
 */
public enum WebUserStateEnum {
    LOGIN_FAIL(-1000, "密码或帐号输入有误"), SUCCESS(1, "操作成功"), 
    NULL_AUTH_INFO(-1001, "注册信息为空"), 
    ONLY_ONE_ACCOUNT(-1002,"一个手机号最多只能绑定一个本地帐号");


    private int state;
    private String stateInfo;

    WebUserStateEnum(int state, String stateInfo) {
        this.state = state;
        this.stateInfo = stateInfo;
    }

    public int getState() {
        return state;
    }

    public String getStateInfo() {
        return stateInfo;
    }

    public static WebUserStateEnum stateOf(int index) {
        for (WebUserStateEnum state : values()) {
            if (state.getState() == index) {
                return state;
            }
        }
        return null;
    }
}
