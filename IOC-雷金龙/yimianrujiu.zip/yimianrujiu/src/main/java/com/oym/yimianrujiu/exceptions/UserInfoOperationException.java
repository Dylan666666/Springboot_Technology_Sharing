package com.oym.yimianrujiu.exceptions;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:28
 */
public class UserInfoOperationException extends RuntimeException {
    private static final long serialVersionUID = -4704507962783305000L;

    public UserInfoOperationException(String message) {
        super(message);
    }
}
