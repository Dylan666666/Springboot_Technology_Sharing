package com.oym.yimianrujiu.exceptions;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:24
 */
public class WebUserOperationException extends RuntimeException{
    
    private static final long serialVersionUID = -8138046613108216904L;

    public WebUserOperationException(String message) {
        super(message);
    }
}
