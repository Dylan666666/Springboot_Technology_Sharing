package com.oym.yimianrujiu.ljl.config;

import com.oym.yimianrujiu.ljl.entity.UserC;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Configuration：代表这是一个Java配置文件，Spring会根据它来生成IoC容器去装配Bean
@Configuration
public class AppConfigC {
    //@Bean：代表将initUserC方法返回的POJO装配到IoC容器中
    //而其属性name定义这个Bean的名称
    // 如果没有配置它，则将方法名initUserC作为Bean的名称保存到IoC容器中。
    @Bean(name = "userC")
    public UserC initUserC() {
        //可以在创建对象时自行使用set方法或构造方法
        UserC userC = new UserC();
        /*userC.setName("ljl");
        userC.setAge(100);*/
        return userC;
    }
}
