package com.oym.yimianrujiu.ljl.config;

import com.oym.yimianrujiu.ljl.entity.UserC;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @ComponentScan 标明会进行扫描
 * @ComponentScan不加任何参数的话只会扫描类AppConfig所在的当前包和其子包
 * @ComponentScan(value = "com.oym.yimianrujiu.ljl.entity", includeFilters =
 * {@Filter(type = FilterType.ANNOTATION, classes = {Controller.class})})
 * excludeFilters 的参数是一个 Filter[] 数组
 * 然后指定 FilterType 的类型为 ANNOTATION
 * 也就是通过注解来过滤，最后的 value 则是Controller 注解类。配置之后
 * 在 spring 扫描的时候，就会跳过 com.oym.yimianrujiu.ljl.entity包下，所有被 @Controller 注解标注的类。
 * excludeFilters= {@Filter(classes= {Service.class})})
 * @author ljl
 */
@ComponentScan(value = "com.oym.yimianrujiu.ljl.entity")
@Configuration
public class AppConfigD {

}
