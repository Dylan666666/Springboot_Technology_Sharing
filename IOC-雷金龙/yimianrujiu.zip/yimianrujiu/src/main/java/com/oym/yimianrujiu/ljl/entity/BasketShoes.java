package com.oym.yimianrujiu.ljl.entity;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
//@Autowired时找到多个相同类型的类时优先使用此类装配
//@Primary：告诉Spring Ioc容器，当发现有多个同样类型的Bean时，请优先使用这个Bean进行注入。
//@Primary
public class BasketShoes implements Shoes {
    @Override
    public void put() {
        System.out.println("穿篮球鞋【"+BasketShoes.class.getSimpleName()+"】去打球");
    }
}
