package com.oym.yimianrujiu.ljl.entity;

public interface Person {
    public void activity();

    public void setShoes(Shoes shoes);
}
