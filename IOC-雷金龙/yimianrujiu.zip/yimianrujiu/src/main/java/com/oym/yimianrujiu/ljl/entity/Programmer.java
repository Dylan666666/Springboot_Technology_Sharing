package com.oym.yimianrujiu.ljl.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Programmer implements Person {
    //@Quelifier：与@Autowired组合指定value，通过类型和名称一起找到Bean。
    @Qualifier("runShoes")
    @Autowired
    private Shoes shoes=null;

    @Override
    public void activity() {
        this.shoes.put();
    }

    @Override
    public void setShoes(Shoes shoes) {
        this.shoes=shoes;
    }
}
