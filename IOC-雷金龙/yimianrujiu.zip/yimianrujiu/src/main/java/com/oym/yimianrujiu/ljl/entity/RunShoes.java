package com.oym.yimianrujiu.ljl.entity;

import org.springframework.stereotype.Component;

@Component
public class RunShoes implements Shoes {
    @Override
    public void put() {
        System.out.println("穿足球鞋【"+RunShoes.class.getSimpleName()+"】去打球");
    }
}