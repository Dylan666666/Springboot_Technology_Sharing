package com.oym.yimianrujiu.ljl.entity;

public interface Shoes {
    public void put();
}
