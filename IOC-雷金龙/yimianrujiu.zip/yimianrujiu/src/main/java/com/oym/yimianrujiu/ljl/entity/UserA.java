package com.oym.yimianrujiu.ljl.entity;

public class UserA {
}
