package com.oym.yimianrujiu.ljl.entity;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/**
 * @Component 表明会被Ioc容器扫描
 * user为Bean的名称,如果不配置默认会把类名第一个小写作为Bean名称
 * @author ljl
 */
@Component("userD")
public class UserD {
    @Value("ljl")
    private String name;
    @Value("101")
    private Integer age;


    public UserD() {
    }

    public UserD(String name, Integer age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "UserC{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
