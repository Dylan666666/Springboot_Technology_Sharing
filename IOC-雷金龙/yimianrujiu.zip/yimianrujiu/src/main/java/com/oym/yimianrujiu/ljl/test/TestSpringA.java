package com.oym.yimianrujiu.ljl.test;

import com.oym.yimianrujiu.ljl.config.AppConfigC;
import com.oym.yimianrujiu.ljl.config.AppConfigD;
import com.oym.yimianrujiu.ljl.entity.*;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringA {
    /**1.xml方式）通过Spring容器创建UserA类的对象
     * (1)在spring配置文件中声明USer类的对象
     *      如果没有配置文件先创建配置文件
     * （2）在程序中通过spring容器获取UserA类的对象
     */

    //xml配置方式
    @Test
    public void testIOCA(){
        //读取spring的核心配置文件
        ClassPathXmlApplicationContext ac =
        new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        //getBean返回对象的类型为Object需要强转
        UserA ua1 = (UserA)ac.getBean("userA");
        //UserA ua1 = ac.getBean(UserA.class);
        UserA ua2 = (UserA)ac.getBean("userA");
        if(ua1 == ua2){
            //也许会引发线程不安全？
            System.out.println("当前UserA对象是单实例的");
        }else{
            System.out.println("当前UserA对象是多实例的");
        }
        System.out.println(ua1);
    }

    @Test
    public void testReflection() throws Exception {
        //可以通过工具解析xml获取类的全路径
        String className = "com.oym.yimianrujiu.ljl.entity.UserA";
        Class clz = Class.forName(className);
        //class.newInstance在JDK1.9被弃用
        UserA ua1 = (UserA)clz.newInstance();
        //获取构造方法来实例对象，1.9以前是只能调用无参构造，现在可以根据传入的参数去匹配具体的构造方法
        ua1 = (UserA)clz.getDeclaredConstructor().newInstance();

        System.out.println(ua1);
    }
    //@Configuration+@Bean方式
    @Test
    public void testIOCC(){
        ApplicationContext ctx =
                new AnnotationConfigApplicationContext(AppConfigC.class);
        //UserC userC = (UserC)ctx.getBean("userC");
        UserC userC = ctx.getBean(UserC.class);
        System.out.println(userC);

    }

    //@Configuration+@ComponentScan方式
    @Test
    public void testIOCD(){
        ApplicationContext ctx =
                new AnnotationConfigApplicationContext(AppConfigD.class);
        //UserC userC = (UserC)ctx.getBean("userC");
        UserD userD = ctx.getBean(UserD.class);
        System.out.println(userD);

    }

    //通过spring为UserB对象的属性赋值
    //set方法注入：底层通过找到setXxx方法为xxx属性赋值getDeclaredMethod()
    //constructor方法注入：底层通过找到对应的构造方法为属性赋值getDeclaredConstructor()
    @Test
    public void testDIB(){
        //读取spring的核心配置文件
        ClassPathXmlApplicationContext ac =
                new ClassPathXmlApplicationContext(
                        "applicationContext.xml");
        //getBean返回对象的类型为Object需要强转
        UserB ub1 = (UserB)ac.getBean("userB");
        System.out.println(ub1);
    }

    @Test
    public void testDIC(){
        ApplicationContext ctx =
                new AnnotationConfigApplicationContext(AppConfigD.class);
        Person person=ctx.getBean(Programmer.class);
        person.activity();
    }

}
