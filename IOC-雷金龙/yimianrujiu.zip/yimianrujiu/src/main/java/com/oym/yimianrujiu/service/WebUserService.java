package com.oym.yimianrujiu.service;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:15
 */
public interface WebUserService {
    
    
    
}
