package com.oym.yimianrujiu.service.impl;

import com.oym.yimianrujiu.service.WebUserService;
import org.springframework.stereotype.Service;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 21:15
 */
@Service
public class WebUserServiceImpl implements WebUserService {
    
    
    
}
