package com.oym.yimianrujiu.web.frontend;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Author: Mr_OO
 * @Date: 2020/6/27 21:23
 */
@Controller
@RequestMapping("/frontend")
public class HelloController {
    
    @GetMapping("/hello")
    public String hello() {
        return "frontend/hello";
    }
    
}
