package com.oym.yimianrujiu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YiMianRuJiuApplicationTests {

    @Test
    void contextLoads() {
    }

}
