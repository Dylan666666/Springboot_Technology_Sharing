package com.oym.yimianrujiu.dao;

import com.oym.yimianrujiu.entity.School;
import com.oym.yimianrujiu.entity.UserInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 20:52
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserInfoDaoTest {
    
    @Resource
    private UserInfoDao userInfoDao;
    
    @Test
    public void insertUserInfoTest() {
        UserInfo userInfo = new UserInfo();
        userInfo.setCreateTime(new Date());
        userInfo.setGender(1);
        userInfo.setWebUserId(2L);
        userInfo.setTrueName("杨春");
        userInfo.setUserType(1);
        System.out.println("插入情况为：" + userInfoDao.insertUserInfo(userInfo));
    }

    @Test
    public void queryUserInfoByIdTest() {
        System.out.println("插入情况为：" + userInfoDao.queryUserInfoById(2L).getTrueName());
    }
    
    @Test
    public void updateUserInfoTest() {
        UserInfo userInfo = new UserInfo();
        userInfo.setSchoolId(1L);
        userInfo.setWebUserId(2L);
        System.out.println("更新情况为：" + userInfoDao.updateUserInfo(userInfo));
    }

    @Test
    public void deleteUserInfoTest() {
        System.out.println("删除情况为: " + userInfoDao.deleteUserInfo(2L));;
    }

    @Test
    public void querySchoolTest() {
        List<School> schools = userInfoDao.querySchool();
        for (School school : schools) {
            System.out.println(school.getSchoolName() + "\t" + school.getSchoolAddress());
        }
    }

    @Test
    public void querySchoolByIdTest() {
        String name = userInfoDao.querySchoolById(1L);
        System.out.println(name);
    }
    
    
}
