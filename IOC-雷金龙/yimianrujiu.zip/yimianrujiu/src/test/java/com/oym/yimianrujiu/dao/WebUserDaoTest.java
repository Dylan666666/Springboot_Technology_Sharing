package com.oym.yimianrujiu.dao;


import com.oym.yimianrujiu.entity.WebUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @Author: Mr_OO
 * @Date: 2020/7/2 13:17
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class WebUserDaoTest {
    
    @Resource
    private WebUserDao webUserDao; 
    
    @Test
    public void insertWebUserTest() {
        WebUser webUser = new WebUser();
        webUser.setName("小白");
        webUser.setPhone(666666L);
        webUser.setPassword("666666");
        webUser.setEnableStatus(1);
        int res = webUserDao.insertWebUser(webUser);
        System.out.println("插入结果为：" + res);
    }
    
    @Test
    public void queryWebUserListTest() {
        WebUser webUser = new WebUser();
        webUser.setName("小");
        List<WebUser> list = webUserDao.queryWebUserList(webUser, 0, 5);
        for (WebUser user : list) {
            System.out.println(user.getName());
        }
        System.out.println("查询的总数为：" + webUserDao.queryWebUserCount(webUser));
    }

    @Test
    public void getWebUserIdTest() {
        System.out.println("id为：" + webUserDao.getWebUserId(123456L));
        System.out.println("名字为：" + webUserDao.queryWebUserById(2L).getName());
        System.out.println("名字为：" + webUserDao.queryWebUserByPhone(123456L).getName());
        System.out.println("名字为：" + webUserDao.queryWebUserByIdAndPwd(2L, "123456").getName());
        System.out.println("更改密码情况为：" + webUserDao.updatePasswordById(2L, "123456", new Date()));
        System.out.println("更改密码情况为：" + webUserDao.updatePasswordByPhone(123456L, "123456", new Date()));
    }
    
}
